import urllib.request
import urllib.parse
import json

def getRtmpUrl():
    # 这个是百度翻译api的地址
    url = 'http://y.yun.joyware.com/vcloud/open/user/login'
    # 准备一下头
    headers = {
        'Content-Type': 'application/x-www-form-urlencoded'
    }
    # 还有我们准备用Post传的值，这里值用字典的形式
    values = {
        'account': 'entTest',
        'passwd': 'e10adc3949ba59abbe56e057f20f883e'
    }
    # 将字典格式化成能用的形式
    data = urllib.parse.urlencode(values).encode('utf-8')
    # 创建一个request,放入我们的地址、数据、头
    request = urllib.request.Request(url, data, headers)
    # 访问
    html = urllib.request.urlopen(request).read().decode('utf-8')
    # 利用json解析包解析返回的json数据 拿到翻译结果
    token = json.loads(html)['body']['access_token']
    # print(json.loads(html)['trans_result']['data'][0]['dst'])
    rtmpurl = getRtmpByToken('ebee8fef-ad6a-496f-b201-f695394b92d7', token)
    print(rtmpurl)
    return rtmpurl

def getRtmpByToken(userid,token):
    url = 'http://y.yun.joyware.com/vcloud/open/media/play'
    headers = {
        'Content-Type': 'application/x-www-form-urlencoded'
    }
    values = {
        'access_token': token,
        'user_id': userid,
        'dev_id': '180505711008993',
        'chan_id': '1',
        'video_type': '1'
    }
    data = urllib.parse.urlencode(values).encode('utf-8')
    request = urllib.request.Request(url, data, headers)
    html = urllib.request.urlopen(request).read().decode('utf-8')
    url2 = json.loads(html)['body']['mrts']['a_ip']
    url3 = json.loads(url2)
    return url3["urls"]["rtmp"]


from django.http import HttpResponse
from django.shortcuts import render
from django.shortcuts import render_to_response
from django.shortcuts import redirect
from . import posttest

def search(request):
    request.encoding = 'utf-8'
    if 'user' in request.GET:
        message = '你搜索的内容为: ' + request.GET['user']
    else:
        message = '你提交了空表单'
    #return HttpResponse("Hello world！")
    #return HttpResponse(message)
    context = {}
    url = posttest.getRtmpUrl()
    print(url)
    context['hello'] = url

    return render(request, 'index2.html', context)
    #return redirect("/static/index.html")

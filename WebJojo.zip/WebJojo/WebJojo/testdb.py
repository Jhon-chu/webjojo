# -*- coding: utf-8 -*-
from django.http import HttpResponse

from WebTest.models import Test


# 数据库操作
def testdb(request):
   # test1 = Test(name='runoob')
  #  test1.save()
    list = Test.objects.all()
    response1 = ""
    response2 = Test.objects.filter(id=1)
    response3 = Test.objects.get(id=1)

    for var in list:
       response1 += var.name + " "
    response = response1

    return HttpResponse("<p>" + response + "</p>")
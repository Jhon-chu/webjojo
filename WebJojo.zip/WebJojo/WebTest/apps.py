from django.apps import AppConfig


class WebtestConfig(AppConfig):
    name = 'WebTest'
